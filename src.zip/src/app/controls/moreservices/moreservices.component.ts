import { Component } from '@angular/core';

@Component({
  selector: 'app-moreservices',
  templateUrl: './moreservices.component.html',
  styleUrls: ['./moreservices.component.scss']
})
export class MoreservicesComponent {

}
